package net.sunmonkey.db.mapper;

import net.sunmonkey.db.model.IpRate;
import org.apache.ibatis.annotations.Param;

public interface IpRateMapper {

    IpRate selectByPrimaryKey(@Param("ip") String ip);
}
