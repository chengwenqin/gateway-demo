package net.sunmonkey.db.mapper;

import net.sunmonkey.db.model.PathRate;
import org.apache.ibatis.annotations.Param;

public interface PathRateMapper {

    PathRate selectByPrimaryKey(@Param("path") String path);
}
