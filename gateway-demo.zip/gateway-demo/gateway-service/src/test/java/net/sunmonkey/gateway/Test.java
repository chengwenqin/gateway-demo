package net.sunmonkey.gateway;

import org.springframework.cloud.gateway.filter.ratelimit.RedisRateLimiter;

public class Test {

    public static void main(String[] args) {
        RedisRateLimiter redisRateLimiter = null;
    }
}
