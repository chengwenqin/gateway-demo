package net.sunmonkey.gateway.service.impl;

import net.sunmonkey.db.mapper.PathRateMapper;
import net.sunmonkey.db.model.PathRate;
import net.sunmonkey.gateway.service.PathRateService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class PathRateServiceImpl implements PathRateService {

    //@Resource
    private PathRateMapper pathRateMapper;

    @Override
    public PathRate get(String path) {
        //电脑上面没有mysql，就先写死吧
        //return pathRateMapper.selectByPrimaryKey(path);
        PathRate pathRate = new PathRate();
        pathRate.setPath("/user-service/user/hello");
        pathRate.setReplenishRate(1);
        pathRate.setBurstCapacity(1);
        return pathRate;
    }
}
