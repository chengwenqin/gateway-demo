package net.sunmonkey.gateway.service;

import net.sunmonkey.db.model.IpRate;

public interface IpRateService {

    IpRate get(String ip);
}
