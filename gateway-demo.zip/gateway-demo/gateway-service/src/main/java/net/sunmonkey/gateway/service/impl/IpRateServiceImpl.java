package net.sunmonkey.gateway.service.impl;

import net.sunmonkey.db.mapper.IpRateMapper;
import net.sunmonkey.db.model.IpRate;
import net.sunmonkey.gateway.service.IpRateService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class IpRateServiceImpl implements IpRateService {

    //@Resource
    private IpRateMapper ipRateMapper;

    @Override
    public IpRate get(String ip) {
        //电脑上面没有mysql，就先写死吧
        //return ipRateMapper.selectByPrimaryKey(ip);
        IpRate ipRate = new IpRate();
        ipRate.setIp("127.0.0.1");
        ipRate.setReplenishRate(1);
        ipRate.setBurstCapacity(1);
        return ipRate;
    }
}
