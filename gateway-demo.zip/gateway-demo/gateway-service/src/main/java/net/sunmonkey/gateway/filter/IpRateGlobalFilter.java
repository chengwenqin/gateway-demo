package net.sunmonkey.gateway.filter;

import net.sunmonkey.db.model.IpRate;
import net.sunmonkey.gateway.limiter.MyRedisRateLimiter;
import net.sunmonkey.gateway.service.IpRateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

/**
 * IP限流过滤器
 */
@Component
public class IpRateGlobalFilter implements Ordered, GlobalFilter {

    @Autowired
    private MyRedisRateLimiter myRedisRateLimiter;

    @Autowired
    private IpRateService ipRateService;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        String ip = exchange.getRequest().getRemoteAddress().getHostName();

        IpRate ipRate = ipRateService.get(ip);

        //如果允许同行，没有超过该ip的流量限制
        if(myRedisRateLimiter.isAllowed("ip:"+ip+":",
                ipRate.getReplenishRate(),
                ipRate.getBurstCapacity())){
            return chain.filter(exchange);
        }else{
            exchange.getResponse().setStatusCode(HttpStatus.TOO_MANY_REQUESTS);
            return exchange.getResponse().setComplete();
        }
    }

    @Override
    public int getOrder() {
        return 1;
    }
}
