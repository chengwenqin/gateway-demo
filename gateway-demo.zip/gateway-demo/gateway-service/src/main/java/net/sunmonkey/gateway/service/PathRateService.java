package net.sunmonkey.gateway.service;

import net.sunmonkey.db.model.PathRate;

public interface PathRateService {

    PathRate get(String path);
}
